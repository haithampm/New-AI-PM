"use client";
import { Bot, CalendarDays, ChartPie, FolderKanban, Headphones, Mail, Mic, ShieldCheck, Ticket, Users } from 'lucide-react';
import { useTheme } from './theme-provider';

const labels = {
  ar: ['الرئيسية','المشاريع','المهام','الفرق','الوكيل','البريد','الاجتماعات','التقويم','التذاكر','الدعم'],
  en: ['Overview','Projects','Tasks','Teams','Assistant','Emails','Meetings','Calendar','Tickets','Support']
} as const;

const items = [ChartPie, FolderKanban, ShieldCheck, Users, Bot, Mail, Mic, CalendarDays, Ticket, Headphones] as const;

export function Sidebar({ locale = 'ar' }: { locale?: string }) {
  const { theme, toggle } = useTheme();
  const copy = locale === 'en' ? labels.en : labels.ar;
  return (
    <aside className="hidden w-72 flex-col border-r border-border bg-surface px-4 py-5 lg:flex">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <svg viewBox="0 0 48 48" className="h-9 w-9 text-primary" aria-label="AI Project Manager Agent logo">
            <rect x="5" y="6" width="14" height="36" rx="6" fill="currentColor" opacity="0.18" />
            <path d="M24 9h10c5 0 9 4 9 9v12c0 5-4 9-9 9H24" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
            <path d="M12 18h12M12 30h18" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
          </svg>
          <div>
            <p className="text-sm font-semibold tracking-[-0.02em] text-text">{locale === 'en' ? 'AI Project Manager' : 'وكيل مدير المشاريع'}</p>
            <p className="text-xs text-muted">{locale === 'en' ? 'Autonomous workspace' : 'مساحة عمل ذاتية'}</p>
          </div>
        </div>
        <button onClick={toggle} className="rounded-lg border border-border bg-surface-2 px-3 py-2 text-xs text-muted">{theme === 'dark' ? (locale === 'en' ? 'Light' : 'فاتح') : (locale === 'en' ? 'Dark' : 'داكن')}</button>
      </div>
      <nav className="space-y-1">
        {copy.map((label, index) => {
          const Icon = items[index];
          return (
            <a href={`#nav-${index}`} key={label} className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm subtle-hover ${index === 0 ? 'bg-[var(--color-primary-soft)] text-text' : 'text-muted hover:bg-surface-2 hover:text-text'}`}>
              <Icon className="h-4 w-4" />
              {label}
            </a>
          );
        })}
      </nav>
      <div className="mt-auto rounded-xl border border-border bg-surface-2 p-4">
        <p className="text-[11px] uppercase tracking-[0.18em] text-faint">{locale === 'en' ? 'Production' : 'الإنتاج'}</p>
        <p className="mt-2 text-sm text-text">{locale === 'en' ? 'Arabic-ready, OAuth-enabled, PostgreSQL-backed, and structured for audited enterprise deployment.' : 'جاهز للعربية، ويدعم OAuth، ومدعوم بـ PostgreSQL ومهيأ لنشر مؤسسي قابل للتدقيق.'}</p>
      </div>
    </aside>
  );
}
