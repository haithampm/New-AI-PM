"use client";
import { DragDropContext, Draggable, Droppable, type DropResult } from '@hello-pangea/dnd';
import { useState } from 'react';
import { overview } from '@/lib/data';
import { Badge, Card } from './ui';
type Task = typeof overview.tasks[number];
type Lane = 'todo' | 'doing' | 'done';
const laneLabels: Record<Lane, string> = { todo: 'To do', doing: 'In progress', done: 'Done' };
export function KanbanBoard() {
  const [tasks, setTasks] = useState<Task[]>(overview.tasks);
  const onDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    const lane = result.destination.droppableId as Lane;
    setTasks((prev) => prev.map((task, index) => index === Number(result.draggableId) ? { ...task, lane } : task));
  };
  return (
    <DragDropContext onDragEnd={onDragEnd}>
      <div className="grid gap-4 lg:grid-cols-3">
        {(['todo', 'doing', 'done'] as Lane[]).map((lane) => (
          <Droppable droppableId={lane} key={lane}>
            {(provided) => (
              <Card className="min-h-64 p-4" ref={provided.innerRef} {...provided.droppableProps}>
                <div className="mb-4 flex items-center justify-between">
                  <h3 className="text-sm font-semibold text-text">{laneLabels[lane]}</h3>
                  <Badge>{tasks.filter((task) => task.lane === lane).length}</Badge>
                </div>
                <div className="space-y-3">
                  {tasks.map((task, index) => task.lane === lane ? (
                    <Draggable draggableId={String(index)} index={index} key={task.id}>
                      {(dragProvided) => (
                        <div ref={dragProvided.innerRef} {...dragProvided.draggableProps} {...dragProvided.dragHandleProps} className="rounded-lg border border-border bg-surface-2 p-3">
                          <p className="text-sm font-medium text-text">{task.title}</p>
                          <div className="mt-3 flex items-center justify-between text-xs text-muted">
                            <span>{task.assignee}</span>
                            <span>{task.due}</span>
                          </div>
                        </div>
                      )}
                    </Draggable>
                  ) : null)}
                  {provided.placeholder}
                </div>
              </Card>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}