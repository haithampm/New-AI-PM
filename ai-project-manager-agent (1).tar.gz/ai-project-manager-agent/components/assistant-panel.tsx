"use client";
import { useState } from 'react';
import { Mic, Send, Sparkles, Volume2 } from 'lucide-react';
import { overview } from '@/lib/data';
import { Card, Badge } from './ui';
export function AssistantPanel({ locale = 'ar' }: { locale?: string }) {
  const ar = locale === 'ar';
  const [message, setMessage] = useState(ar ? 'ما حالة مشروع Smart City Rollout؟' : 'What is the status of Smart City Rollout?');
  const [response, setResponse] = useState(ar ? 'الوكيل جاهز. اطلب قراراً أو خطة معالجة أو تعييناً تلقائياً للمهام.' : 'AI PM Agent is ready. Ask for a decision, a mitigation plan, or an autonomous task assignment.');
  const submit = async () => {
    const res = await fetch('/api/assistant', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message, locale }) });
    const data = await res.json();
    setResponse(data.response);
  };
  const prompts = ar ? ['ما حالة المشروع؟','أنشئ ميثاق مشروع','لخص البريد غير المقروء','حوّل الاجتماع إلى مهام'] : overview.assistant.suggestedPrompts;
  return (
    <Card className="p-5">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <div className="mb-2 flex items-center gap-2"><Badge tone="blue">{ar ? 'وكيل ذكي' : 'AI operator'}</Badge><span className="text-xs text-faint">{ar ? 'صوت + محادثة' : 'Voice + chat'}</span></div>
          <p className="text-lg font-semibold tracking-[-0.02em] text-text">{ar ? 'مركز القرار' : 'Decision cockpit'}</p>
          <p className="text-sm text-muted">{ar ? 'ردود ذاتية، ملخصات، قرارات، وتوصيات توزيع.' : 'Autonomous responses, status checks, summaries, and assignment proposals.'}</p>
        </div>
        <div className="flex gap-2">
          <button className="rounded-lg border border-border bg-surface-2 p-2 text-muted" aria-label="Voice input"><Mic className="h-4 w-4" /></button>
          <button className="rounded-lg border border-border bg-surface-2 p-2 text-muted" aria-label="Text to speech"><Volume2 className="h-4 w-4" /></button>
        </div>
      </div>
      <div className="rounded-xl border border-border bg-surface-2 p-4 text-sm leading-6 text-text">{response}</div>
      <div className="mt-4 flex gap-3">
        <input value={message} onChange={(e) => setMessage(e.target.value)} className="flex-1 rounded-lg border border-border bg-transparent px-4 py-3 text-sm" placeholder={ar ? 'اطلب من الوكيل اتخاذ قرار أو تنفيذ إجراء' : 'Ask the agent to decide or act'} />
        <button onClick={submit} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-3 text-sm font-semibold text-white"><Send className="h-4 w-4" />{ar ? 'إرسال' : 'Send'}</button>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {prompts.map((prompt) => (
          <button key={prompt} onClick={() => setMessage(prompt)} className="inline-flex items-center gap-2 rounded-full border border-border bg-surface-2 px-3 py-2 text-xs text-muted">
            <Sparkles className="h-3 w-3" />{prompt}
          </button>
        ))}
      </div>
    </Card>
  );
}
