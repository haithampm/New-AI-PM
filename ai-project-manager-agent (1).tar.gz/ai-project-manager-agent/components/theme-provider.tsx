"use client";
import { createContext, useContext, useEffect, useMemo, useState } from 'react';
type Theme = 'light' | 'dark';
const ThemeContext = createContext<{theme: Theme; toggle: () => void}>({ theme: 'light', toggle: () => undefined });
export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('light');
  useEffect(() => {
    const dark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const next = dark ? 'dark' : 'light';
    setTheme(next);
    document.documentElement.setAttribute('data-theme', next);
  }, []);
  const value = useMemo(() => ({
    theme,
    toggle: () => {
      const next = theme === 'dark' ? 'light' : 'dark';
      setTheme(next);
      document.documentElement.setAttribute('data-theme', next);
    }
  }), [theme]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}
export const useTheme = () => useContext(ThemeContext);