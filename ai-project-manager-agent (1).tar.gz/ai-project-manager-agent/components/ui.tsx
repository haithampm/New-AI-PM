import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';
export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn('panel rounded-xl border border-border bg-surface shadow-sm', className)}>{children}</div>;
}
export function SectionTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-4">
      <div className="flex flex-col gap-1">
        <h2 className="text-lg font-semibold tracking-[-0.02em] text-text">{title}</h2>
        {subtitle ? <p className="text-sm text-muted">{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}
export function Badge({ children, tone = 'default' }: { children: ReactNode; tone?: 'default' | 'success' | 'warning' | 'error' | 'blue' }) {
  const styles = {
    default: 'bg-surface-3 text-muted border-border',
    success: 'bg-green-50 text-success border-green-200 dark:bg-green-950/30 dark:border-green-900',
    warning: 'bg-amber-50 text-warning border-amber-200 dark:bg-amber-950/30 dark:border-amber-900',
    error: 'bg-pink-50 text-error border-pink-200 dark:bg-pink-950/30 dark:border-pink-900',
    blue: 'border-transparent bg-[var(--color-primary-soft)] text-primary'
  } as const;
  return <span className={cn('inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium', styles[tone])}>{children}</span>;
}
