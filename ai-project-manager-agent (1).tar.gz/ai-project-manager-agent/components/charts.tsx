"use client";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { overview } from '@/lib/data';
export function VelocityChart() {
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={overview.chart}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(120,120,120,.18)" />
          <XAxis dataKey="name" stroke="currentColor" fontSize={12} />
          <YAxis stroke="currentColor" fontSize={12} />
          <Tooltip />
          <Bar dataKey="created" fill="var(--color-blue)" radius={[8, 8, 0, 0]} />
          <Bar dataKey="completed" fill="var(--color-primary)" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}