import { NextResponse } from 'next/server';
import { overview } from '@/lib/data';
export async function GET() {
  return NextResponse.json(overview);
}