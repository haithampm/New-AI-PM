import { NextRequest, NextResponse } from 'next/server';
import { assistantResponses } from '@/lib/data';
export async function POST(request: NextRequest) {
  const { message = '', locale = 'ar' } = await request.json();
  const normalized = String(message).toLowerCase();
  const ar = locale === 'ar';
  let response = ar
    ? 'يقترح الوكيل الذكي التركيز على معالجة مخاطر Smart City Rollout، وإعادة توزيع عبء العمل، وتحويل مخرجات الاجتماعات الأخيرة إلى مهام بمواعيد نهائية.'
    : assistantResponses.default;
  if (normalized.includes('status') || normalized.includes('حالة')) {
    response = ar
      ? 'مشروع Smart City Rollout مكتمل بنسبة 84%، ولديه ثلاث مراحل مستحقة هذا الشهر، وما زال معرضاً للخطر بسبب تأخر اعتماد التكامل.'
      : assistantResponses.status;
  }
  if (normalized.includes('charter') || normalized.includes('plan') || normalized.includes('ميثاق') || normalized.includes('خطة')) {
    response = ar
      ? 'ميثاق المشروع: الهدف هو نشر منصة بنية تحتية ذكية متعددة المواقع؛ النطاق يشمل أجهزة إنترنت الأشياء ولوحات التحكم ومسارات الدعم؛ النجاح يقاس بتوفر 95% وتقليل زمن معالجة الأعطال بنسبة 30%.'
      : assistantResponses.charter;
  }
  return NextResponse.json({ response, mode: 'localized-agent' });
}
