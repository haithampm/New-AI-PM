import { auth } from '@/auth';
import { NextResponse } from 'next/server';
import { listOutlookCalendarEvents } from '@/lib/microsoft';
export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const events = await listOutlookCalendarEvents(session.user.id);
  return NextResponse.json({ provider: 'outlook-calendar', events });
}
