import { auth } from '@/auth';
import { NextResponse } from 'next/server';
import { listOutlookMessages } from '@/lib/microsoft';
import { summarizeInboxToTasks, persistDecision } from '@/lib/agent';
export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const messages = await listOutlookMessages(session.user.id);
  const suggestedTasks = await summarizeInboxToTasks(session.user.id, messages.map((m: { bodyPreview?: string }) => ({ snippet: m.bodyPreview })));
  await persistDecision(session.user.id, 'Fetched Outlook messages and prepared task suggestions', { count: messages.length });
  return NextResponse.json({ provider: 'outlook', messages, suggestedTasks });
}
