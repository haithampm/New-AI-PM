import { NextResponse } from 'next/server';
export async function GET() {
  return NextResponse.json({
    gmail: { connected: true, provider: 'Google OAuth', lastSync: '2026-04-06T12:50:00Z' },
    outlook: { connected: false, provider: 'Microsoft OAuth', action: 'Connect account' },
    calendar: { connected: true, provider: 'Google Calendar', eventsImported: 18 },
    projectImport: { supported: ['MPP', 'XML', 'CSV'], mode: 'planned-adapter' }
  });
}