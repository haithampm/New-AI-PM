import { auth } from '@/auth';
import { NextResponse } from 'next/server';
import { listGoogleCalendarEvents } from '@/lib/google';
export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const events = await listGoogleCalendarEvents(session.user.id);
  return NextResponse.json({ provider: 'google-calendar', events });
}
