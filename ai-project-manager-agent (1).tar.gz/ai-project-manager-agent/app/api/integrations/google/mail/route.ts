import { auth } from '@/auth';
import { NextResponse } from 'next/server';
import { listGmailMessages } from '@/lib/google';
import { summarizeInboxToTasks, persistDecision } from '@/lib/agent';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const messages = await listGmailMessages(session.user.id);
  const suggestedTasks = await summarizeInboxToTasks(session.user.id, messages);
  await persistDecision(session.user.id, 'Fetched Gmail messages and prepared task suggestions', { count: messages.length });
  return NextResponse.json({ provider: 'gmail', messages, suggestedTasks });
}
