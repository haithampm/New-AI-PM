import { NextResponse } from 'next/server';
export async function POST() {
  return NextResponse.json({
    transcript: 'Meeting transcript mock output.',
    summary: 'Weekly governance meeting covered integration risk, support SLA, and rollout approvals.',
    actionItems: [
      'Finalize vendor API approvals by Wednesday.',
      'Convert meeting decisions into 4 new tasks.',
      'Share executive dashboard before Thursday noon.'
    ],
    translation: { source: 'en', targets: ['ar', 'fr'] }
  });
}