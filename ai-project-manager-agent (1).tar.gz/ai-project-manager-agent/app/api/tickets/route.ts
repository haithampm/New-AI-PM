import { NextResponse } from 'next/server';
import { overview } from '@/lib/data';
export async function GET() {
  return NextResponse.json({ tickets: overview.tickets, slaPolicy: { critical: '30m', high: '2h', medium: '8h', low: '24h' } });
}