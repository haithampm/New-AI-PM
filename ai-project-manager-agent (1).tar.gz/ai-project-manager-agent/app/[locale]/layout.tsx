import '../globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import { getDictionary } from '@/lib/i18n';

export default async function LocaleLayout({ children, params }: { children: React.ReactNode; params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  return (
    <html lang={locale} dir={dict.direction}>
      <body>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
