import { Sidebar } from '@/components/sidebar';
import { Card, Badge, SectionTitle } from '@/components/ui';
import { VelocityChart } from '@/components/charts';
import { KanbanBoard } from '@/components/kanban';
import { AssistantPanel } from '@/components/assistant-panel';
import { overview } from '@/lib/data';
import { getDictionary } from '@/lib/i18n';
import { Activity, Bot, BrainCircuit, MessageSquareShare, Radar, ShieldAlert, Sparkles, TrendingUp, Users } from 'lucide-react';

const agents = [
  ['Orchestrator Agent', 'Routes work, governs approvals, and coordinates autonomous operations.', BrainCircuit],
  ['Task Planner', 'Turns conversations, signals, and updates into assigned tasks with dependencies.', Sparkles],
  ['Risk Engine', 'Predicts slips and proposes mitigation before the schedule moves red.', Radar],
  ['Comms Agent', 'Drafts updates, reminders, simulated replies, and escalation messaging.', MessageSquareShare]
] as const;

const loops = [
  { title: 'Observe', text: 'Signals stream from tasks, meetings, support, and workload.' },
  { title: 'Decide', text: 'The agent scores confidence, urgency, and business impact.' },
  { title: 'Act', text: 'Assignments, summaries, escalations, and plans are issued automatically.' },
  { title: 'Learn', text: 'User overrides and outcomes improve future actions.' }
];

export default async function LocaleHomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  const isAr = locale === 'ar';
  return (
    <div className="grid min-h-screen lg:grid-cols-[18rem_1fr]">
      <Sidebar locale={locale} />
      <main className="min-h-screen overflow-y-auto">
        <div className="border-b border-border bg-bg/90 px-5 py-4 lg:px-8">
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-[0.16em] text-faint">{dict.workspace}</p>
              <h1 className="mt-1 text-2xl font-semibold tracking-[-0.04em] text-text">{dict.title}</h1>
            </div>
            <div className="flex items-center gap-3">
              <a href={locale === 'ar' ? '/en' : '/ar'} className="rounded-lg border border-border bg-surface px-4 py-2.5 text-sm font-medium text-text">{locale === 'ar' ? 'English' : 'العربية'}</a>
              <button className="rounded-lg border border-border bg-surface px-4 py-2.5 text-sm font-medium text-text">{dict.reviewQueue}</button>
              <button className="rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-white">{dict.autonomousMode}</button>
            </div>
          </div>
        </div>

        <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-6 lg:px-8">
          <section className="grid gap-6 xl:grid-cols-[1.25fr_0.75fr]">
            <Card className="grid-bg overflow-hidden p-6">
              <div className="flex flex-wrap items-center gap-2"><Badge tone="blue">{dict.aiFirst}</Badge><Badge>{isAr ? 'جاهز للمؤسسات' : 'Enterprise-ready'}</Badge></div>
              <h2 className="mt-4 max-w-3xl text-3xl font-semibold tracking-[-0.05em] text-text">{dict.heroTitle}</h2>
              <p className="mt-4 max-w-2xl text-sm leading-6 text-muted">{dict.heroText}</p>
              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                <div className="rounded-xl border border-border bg-surface-2 p-4"><p className="text-xs text-faint">{isAr ? 'دقة القرار' : 'Decision confidence'}</p><p className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-text">91%</p></div>
                <div className="rounded-xl border border-border bg-surface-2 p-4"><p className="text-xs text-faint">{isAr ? 'الإجراءات الآلية' : 'Automated actions'}</p><p className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-text">38</p></div>
                <div className="rounded-xl border border-border bg-surface-2 p-4"><p className="text-xs text-faint">{isAr ? 'المخاطر التي تم تجنبها' : 'Risk events prevented'}</p><p className="mt-2 text-2xl font-semibold tracking-[-0.03em] text-text">12</p></div>
              </div>
            </Card>
            <AssistantPanel locale={locale} />
          </section>

          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {overview.stats.map((item, idx) => {
              const labels = [dict.activeProjects, dict.openTasks, dict.supportSla, dict.automations];
              return (
                <Card key={item.label} className="subtle-hover p-5">
                  <p className="text-sm text-muted">{labels[idx] ?? item.label}</p>
                  <p className="mt-3 text-3xl font-semibold tracking-[-0.04em] text-text">{item.value}</p>
                  <p className="mt-2 text-xs text-faint">{item.delta}</p>
                </Card>
              );
            })}
          </section>

          <section className="grid gap-6 xl:grid-cols-[1.3fr_0.7fr]">
            <Card className="p-5">
              <SectionTitle title={dict.executionSignals} subtitle={isAr ? 'إيقاع التنفيذ واتجاهات الأداء' : 'Operational throughput and AI decision rhythm'} action={<Badge tone="blue">{isAr ? 'مباشر' : 'Live insights'}</Badge>} />
              <div className="mt-6"><VelocityChart /></div>
            </Card>
            <Card className="p-5">
              <SectionTitle title={isAr ? 'حلقة العمل الذاتية' : 'Autonomous loop'} subtitle={isAr ? 'يراقب ويقرر وينفذ ويتعلم' : 'Observe, decide, act, and learn'} />
              <div className="mt-5 space-y-3">
                {loops.map((loop, index) => (
                  <div key={loop.title} className="rounded-xl border border-border bg-surface-2 p-4">
                    <div className="mb-2 flex items-center gap-3"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--color-primary-soft)] text-xs font-semibold text-primary">0{index + 1}</div><p className="text-sm font-semibold text-text">{isAr ? ['يراقب','يقرر','ينفذ','يتعلم'][index] : loop.title}</p></div>
                    <p className="text-sm text-muted">{isAr ? ['تتدفق الإشارات من المهام والاجتماعات والدعم والضغط التشغيلي.','يقيم الوكيل الثقة والأولوية والأثر على العمل.','ينشئ المهام ويرسل التحديثات ويقترح خطط المعالجة تلقائياً.','يتحسن الأداء من خلال التعديلات والنتائج الفعلية.'][index] : loop.text}</p>
                  </div>
                ))}
              </div>
            </Card>
          </section>

          <section>
            <SectionTitle title={dict.taskGeneration} subtitle={isAr ? 'إنشاء عمل منظم بأقل إدخال يدوي ممكن' : 'Structured work creation with minimal manual input'} action={<Badge>{dict.automationFirst}</Badge>} />
            <div className="mt-4"><KanbanBoard /></div>
          </section>

          <section className="grid gap-6 xl:grid-cols-[1.15fr_0.85fr]">
            <Card className="p-5">
              <SectionTitle title={isAr ? 'بنية الوكلاء' : 'Agent architecture'} subtitle={isAr ? 'وحدات متخصصة مع حوكمة مؤسسية' : 'Specialized modules with enterprise governance'} />
              <div className="mt-5 grid gap-4 md:grid-cols-2">
                {agents.map(([title, description, Icon], index) => (
                  <div key={title} className="subtle-hover rounded-xl border border-border bg-surface-2 p-4">
                    <Icon className="h-5 w-5 text-primary" />
                    <p className="mt-4 text-sm font-semibold text-text">{isAr ? ['وكيل التنسيق','مخطط المهام','محرك المخاطر','وكيل التواصل'][index] : title}</p>
                    <p className="mt-2 text-sm leading-6 text-muted">{isAr ? ['يوجه العمل ويطبق الضوابط ويحدد متى ينفذ تلقائياً.','يحوّل الاجتماعات والإشارات إلى مهام مع تبعيات وتواريخ.','يتوقع التأخير ويقترح خطط التخفيف قبل تعثر الجدول.','يصوغ التحديثات والتذكيرات ورسائل التصعيد.'][index] : description}</p>
                  </div>
                ))}
              </div>
            </Card>
            <Card className="p-5">
              <SectionTitle title={isAr ? 'الذاكرة والتعلم' : 'Memory and learning'} subtitle={isAr ? 'احتفاظ بالسياق لتحسين القرار الذاتي' : 'Persistent context for better autonomous behavior'} />
              <div className="mt-5 space-y-4">
                <div className="rounded-xl border border-border bg-surface-2 p-4"><div className="mb-2 flex items-center gap-2 text-text"><Activity className="h-4 w-4 text-primary" />{isAr ? 'ذاكرة العمل' : 'Working memory'}</div><p className="text-sm text-muted">{isAr ? 'تحتفظ بحالة المشروع الحالية والعوائق والإجراءات المفتوحة.' : 'Current project state, open blockers, active conversations, and pending actions.'}</p></div>
                <div className="rounded-xl border border-border bg-surface-2 p-4"><div className="mb-2 flex items-center gap-2 text-text"><Bot className="h-4 w-4 text-primary" />{isAr ? 'ذاكرة القرار' : 'Decision memory'}</div><p className="text-sm text-muted">{isAr ? 'تحفظ الموافقات السابقة والتفضيلات وأنماط المعالجة الناجحة.' : 'Prior approvals, preferences, escalations, and successful mitigation patterns.'}</p></div>
                <div className="rounded-xl border border-border bg-surface-2 p-4"><div className="mb-2 flex items-center gap-2 text-text"><TrendingUp className="h-4 w-4 text-primary" />{isAr ? 'حلقة التعلم' : 'Learning loop'}</div><p className="text-sm text-muted">{isAr ? 'تضبط التخصيص والتذكيرات وحدود المخاطر حسب النتائج الفعلية.' : 'Adjusts assignment logic, reminder timing, and risk thresholds from outcomes.'}</p></div>
              </div>
            </Card>
          </section>

          <section className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
            <Card className="p-5">
              <SectionTitle title={isAr ? 'حالة المشاريع والمخاطر' : 'Projects and risk posture'} subtitle={isAr ? 'رؤية مؤسسية أنظف للمراحل والصحة والتدخلات' : 'A cleaner enterprise view of milestones, health, and intervention timing'} />
              <div className="mt-5 space-y-4">
                {overview.health.map((project) => (
                  <div key={project.name} className="rounded-xl border border-border bg-surface-2 p-4">
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div>
                        <p className="text-sm font-semibold text-text">{project.name}</p>
                        <p className="text-xs text-muted">{isAr ? `المالك: ${project.owner}` : `Owner: ${project.owner}`}</p>
                      </div>
                      <Badge tone={project.status === 'On track' ? 'success' : project.status === 'At risk' ? 'warning' : 'error'}>{isAr ? (project.status === 'On track' ? 'سليم' : project.status === 'At risk' ? 'معرض للخطر' : 'يحتاج مراجعة') : project.status}</Badge>
                    </div>
                    <div className="mt-4 h-2 rounded-full bg-[var(--color-surface-3)]"><div className="h-2 rounded-full bg-primary" style={{ width: `${project.progress}%` }} /></div>
                    <div className="mt-2 flex justify-between text-xs text-muted"><span>{project.progress}% {isAr ? 'مكتمل' : 'complete'}</span><span>{isAr ? 'مراجعة ذكية خلال 48 ساعة' : 'AI checkpoint in 48h'}</span></div>
                  </div>
                ))}
              </div>
            </Card>
            <Card className="p-5">
              <SectionTitle title={isAr ? 'التنبؤ بالتأخير' : 'Delay prediction'} subtitle={isAr ? 'خطط معالجة قبل تعثر الجداول' : 'Mitigations generated before timelines break'} />
              <div className="mt-5 space-y-4">
                <div className="rounded-xl border border-border bg-surface-2 p-4 text-sm text-muted">
                  <div className="mb-2 flex items-center gap-2 text-text"><ShieldAlert className="h-4 w-4 text-warning" />{isAr ? 'خطر تأخير متوقع' : 'Predicted delay risk'}</div>
                  {isAr ? 'مشروع Smart City Rollout لديه احتمال 71% لتعثر إحدى المراحل بسبب بطء الموافقات وتركيز التبعيات.' : 'Smart City Rollout shows a 71% probability of milestone slip due to approval lag and dependency concentration.'}
                </div>
                <div className="rounded-xl border border-border bg-surface-2 p-4 text-sm text-muted">
                  <p className="font-semibold text-text">{isAr ? 'خطة المعالجة المقترحة' : 'Recommended mitigation plan'}</p>
                  <ul className="mt-3 list-disc space-y-2 ps-5">
                    <li>{isAr ? 'تقسيم الموافقات إلى إطلاقات مرحلية.' : 'Split approval into phased releases.'}</li>
                    <li>{isAr ? 'إعادة توزيع مراجعات كريم إلى سالم.' : 'Rebalance review load to Salem.'}</li>
                    <li>{isAr ? 'تصعيد تأخر المورد بعد 24 ساعة دون رد.' : 'Escalate vendor delay after 24 hours of no response.'}</li>
                  </ul>
                </div>
                <div className="rounded-xl border border-border bg-surface-2 p-4 text-sm text-muted">
                  <div className="mb-2 flex items-center gap-2 text-text"><Users className="h-4 w-4 text-primary" />{isAr ? 'استجابة الفريق المتوقعة' : 'Simulated team response'}</div>
                  {isAr ? 'سالم متاح لمراجعتين هذا الأسبوع، بينما كريم أعلى من حد الضغط المسموح.' : 'Salem is available for two review tasks this week, while Karim is above the workload threshold.'}
                </div>
              </div>
            </Card>
          </section>
        </div>
      </main>
    </div>
  );
}
