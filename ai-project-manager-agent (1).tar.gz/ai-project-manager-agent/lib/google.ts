import { google } from 'googleapis';
import { prisma } from '@/lib/prisma';

async function getGoogleAccount(userId: string) {
  return prisma.account.findFirst({ where: { userId, provider: 'google' } });
}

export async function getGoogleOAuthClient(userId: string) {
  const account = await getGoogleAccount(userId);
  if (!account?.refresh_token) throw new Error('Google account not connected');
  const client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
  client.setCredentials({
    refresh_token: account.refresh_token,
    access_token: account.access_token ?? undefined,
    expiry_date: account.expires_at ? account.expires_at * 1000 : undefined
  });
  return client;
}

export async function listGmailMessages(userId: string, maxResults = 10) {
  const auth = await getGoogleOAuthClient(userId);
  const gmail = google.gmail({ version: 'v1', auth });
  const list = await gmail.users.messages.list({ userId: 'me', maxResults });
  return Promise.all((list.data.messages ?? []).map(async (message) => {
    const detail = await gmail.users.messages.get({ userId: 'me', id: message.id! });
    return {
      id: detail.data.id,
      snippet: detail.data.snippet,
      internalDate: detail.data.internalDate,
      payload: detail.data.payload
    };
  }));
}

export async function listGoogleCalendarEvents(userId: string) {
  const auth = await getGoogleOAuthClient(userId);
  const calendar = google.calendar({ version: 'v3', auth });
  const res = await calendar.events.list({
    calendarId: 'primary',
    singleEvents: true,
    orderBy: 'startTime',
    timeMin: new Date().toISOString(),
    maxResults: 10
  });
  return res.data.items ?? [];
}
