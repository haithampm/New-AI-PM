export const dictionaries = {
  ar: {
    direction: 'rtl',
    language: 'العربية',
    workspace: 'مساحة العمل المؤسسية',
    title: 'وكيل مدير المشاريع الذكي',
    subtitle: 'منصة تشغيل ذاتية للمشاريع والقرارات والمهام والتواصل',
    autonomousMode: 'الوضع الذاتي',
    reviewQueue: 'مراجعة قائمة الإجراءات',
    aiFirst: 'تشغيل ذكي أولاً',
    heroTitle: 'نظام تشغيل ذاتي لإدارة المشاريع والقرارات والمهام والتواصل المؤسسي',
    heroText: 'مبني لفرق المؤسسات التي تحتاج إلى وضوح وسرعة وأتمتة قابلة للتدقيق عبر تنفيذ المشاريع والمخاطر والاجتماعات والبريد والدعم.',
    decisionCockpit: 'مركز القرار',
    askPlaceholder: 'اطلب من الوكيل اتخاذ قرار أو تنفيذ إجراء',
    activeProjects: 'المشاريع النشطة',
    openTasks: 'المهام المفتوحة',
    supportSla: 'الالتزام باتفاقية الخدمة',
    automations: 'الإجراءات الآلية',
    executionSignals: 'إشارات التنفيذ',
    taskGeneration: 'التوليد التلقائي للمهام',
    automationFirst: 'الأتمتة أولاً'
  },
  en: {
    direction: 'ltr',
    language: 'English',
    workspace: 'Enterprise workspace',
    title: 'AI Project Manager Agent',
    subtitle: 'Autonomous operating system for projects, decisions, tasks, and communication',
    autonomousMode: 'Autonomous mode',
    reviewQueue: 'Review queue',
    aiFirst: 'AI-first operations',
    heroTitle: 'An autonomous operating system for project delivery, decisions, tasks, and enterprise communication',
    heroText: 'Built for enterprise teams that need clarity, speed, and auditable automation across delivery, risk, meetings, email, and support.',
    decisionCockpit: 'Decision cockpit',
    askPlaceholder: 'Ask the agent to decide or act',
    activeProjects: 'Active projects',
    openTasks: 'Open tasks',
    supportSla: 'Support SLA',
    automations: 'Automations',
    executionSignals: 'Execution signals',
    taskGeneration: 'Automatic task generation',
    automationFirst: 'Automation first'
  }
} as const;

export type Locale = keyof typeof dictionaries;
export function getDictionary(locale: string) {
  return dictionaries[(locale === 'en' ? 'en' : 'ar') as Locale];
}
