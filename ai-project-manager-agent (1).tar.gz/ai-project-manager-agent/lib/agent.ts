import { prisma } from '@/lib/prisma';

export async function summarizeInboxToTasks(userId: string, messages: Array<{ snippet?: string | null }>) {
  const summaries = messages.map((m, index) => ({
    title: `Follow up from email ${index + 1}`,
    status: 'todo',
    priority: 'medium',
    source: 'email',
    assigneeId: userId
  }));
  return summaries;
}

export async function persistDecision(userId: string, summary: string, metadata?: unknown) {
  return prisma.decision.create({
    data: {
      userId,
      summary,
      confidence: 0.82,
      actionTaken: true,
      metadata: metadata as never
    }
  });
}
