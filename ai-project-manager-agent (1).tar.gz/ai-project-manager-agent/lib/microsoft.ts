import { Client } from '@microsoft/microsoft-graph-client';
import 'isomorphic-fetch';
import { prisma } from '@/lib/prisma';

async function getMicrosoftAccessToken(userId: string) {
  const account = await prisma.account.findFirst({ where: { userId, provider: 'microsoft-entra-id' } });
  if (!account?.access_token) throw new Error('Microsoft account not connected');
  return account.access_token;
}

export async function getGraphClient(userId: string) {
  const accessToken = await getMicrosoftAccessToken(userId);
  return Client.init({ authProvider: (done) => done(null, accessToken) });
}

export async function listOutlookMessages(userId: string) {
  const client = await getGraphClient(userId);
  const res = await client.api('/me/messages').top(10).select(['id', 'subject', 'from', 'receivedDateTime', 'bodyPreview']).get();
  return res.value ?? [];
}

export async function listOutlookCalendarEvents(userId: string) {
  const client = await getGraphClient(userId);
  const res = await client.api('/me/events').top(10).select(['id', 'subject', 'start', 'end', 'organizer']).get();
  return res.value ?? [];
}
