export const overview = {
  stats: [
    { label: 'Active projects', value: 12, delta: '+2 this week' },
    { label: 'Open tasks', value: 148, delta: '31 due soon' },
    { label: 'Support SLA', value: '96.4%', delta: '+1.1% vs target' },
    { label: 'AI automations', value: 38, delta: '14 generated today' }
  ],
  health: [
    { name: 'Smart City Rollout', progress: 84, status: 'At risk', owner: 'Noura' },
    { name: 'Citizen App 2.0', progress: 63, status: 'On track', owner: 'Salem' },
    { name: 'Lighting Analytics', progress: 48, status: 'Needs review', owner: 'Maya' }
  ],
  tasks: [
    { id: 'TK-12', title: 'Approve integration scope', priority: 'High', assignee: 'Noura', due: 'Today', lane: 'todo' },
    { id: 'TK-14', title: 'Review AI charter draft', priority: 'Medium', assignee: 'Karim', due: 'Tomorrow', lane: 'doing' },
    { id: 'TK-19', title: 'Publish milestone update', priority: 'Low', assignee: 'Maya', due: 'Apr 10', lane: 'done' }
  ],
  chart: [
    { name: 'Mon', completed: 16, created: 22 },
    { name: 'Tue', completed: 22, created: 20 },
    { name: 'Wed', completed: 27, created: 24 },
    { name: 'Thu', completed: 19, created: 21 },
    { name: 'Fri', completed: 31, created: 25 },
    { name: 'Sat', completed: 14, created: 18 },
    { name: 'Sun', completed: 18, created: 15 }
  ],
  workload: [
    { name: 'Noura', utilization: 88 },
    { name: 'Salem', utilization: 72 },
    { name: 'Maya', utilization: 63 },
    { name: 'Karim', utilization: 91 }
  ],
  tickets: [
    { id: 'SUP-401', subject: 'OAuth callback mismatch', priority: 'Critical', sla: '23m', status: 'In progress' },
    { id: 'SUP-398', subject: 'Project import mapping help', priority: 'Medium', sla: '1h 40m', status: 'Waiting on user' }
  ],
  assistant: {
    suggestedPrompts: [
      'What is the status of Smart City Rollout?',
      'Generate a project charter for a new IoT deployment',
      'Convert today\'s meeting into tasks',
      'Summarize unread client emails'
    ]
  }
};
export const assistantResponses: Record<string, string> = {
  default: 'AI PM Agent suggests focusing on Smart City Rollout risk mitigation, rebalancing Karim\'s workload, and converting the latest meeting actions into deadline-backed tasks.',
  status: 'Project Smart City Rollout is 84% complete, has 3 milestones due this month, and remains at risk because integration approval is still pending.',
  charter: 'Project Charter: Objective—deploy a multi-site smart infrastructure platform; Scope—IoT devices, dashboards, support workflows; Success—95% uptime, 30% faster issue resolution, executive KPI visibility.'
};